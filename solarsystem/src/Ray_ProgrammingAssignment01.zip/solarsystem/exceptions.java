
package solarsystem;


 class DuplicateCelestialBodyException extends Exception {
     public DuplicateCelestialBodyException(String str)
     {
         super(str);
     }
 }
     class InvalidCelestialBodyException extends Exception {
     public InvalidCelestialBodyException(String str)
     {
         super(str);
     }
 }    

