/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package complexnumber;

/**
 *
 * @author epicb
 */
public interface ArithmeticOpe {
    public abstract Object addition(Object comp);
    public abstract Object subtraction(Object comp);
    ;
    
}
